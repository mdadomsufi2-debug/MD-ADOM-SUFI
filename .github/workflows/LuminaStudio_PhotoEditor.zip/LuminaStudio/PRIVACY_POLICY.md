# Privacy Policy: Lumina Studio (Android app)

Last updated: [DATE]

Lumina Studio (package `com.webtoolshub.lumina`) is an offline photo editor published by [YOUR NAME / WebTools HUB].

**Data collection:** The app does not collect, store on any server, transmit or share any personal data. It has no accounts, analytics, tracking or advertising, and it does not request the INTERNET permission.

**Your photos:** Photos you choose are opened through Android's system photo picker (or taken with your camera app) and edited only on your device. Edited photos are saved to Pictures/Lumina Studio on your device only when you tap Save. When you tap Share, the photo is passed to the app you choose; that app's own privacy policy applies from then on. Temporary files are kept in the app's private cache.

**Permissions:** The app requests no permissions.

**Children:** The app does not knowingly collect information from anyone, including children.

**Changes:** If this policy changes, the date above will be updated.

**Contact:** [YOUR EMAIL]
