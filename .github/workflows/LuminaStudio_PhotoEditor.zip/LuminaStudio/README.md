# Lumina Studio: offline photo editor

Package `com.webtoolshub.lumina` | Java | minSdk 29 | compile/target SDK 36 | AGP 8.11.1 | Gradle 8.14
No third-party libraries (only AndroidX + Material). No permissions, no internet, no ads.

## Open and run
1. Android Studio -> File -> Open -> select this folder (`LuminaStudio`).
2. Wait for Gradle sync (internet needed the first time).
3. Run on a device or emulator with Android 10+.

## Build
- Debug APK: Build -> Build Bundle(s) / APK(s) -> Build APK(s)
- Release AAB for Google Play: Build -> Generate Signed App Bundle / APK -> Android App Bundle.
  Back up the keystore and passwords.

## Tools (29)
Adjust: Tune, Details, Dehaze, Tone Contrast, Levels, White Balance, Color, Black & White, HDR
Effects: Looks (12 presets), Vignette, Lens Blur, Tilt-Shift, Motion Blur, Film Grain, Soft Glow, Bloom, Halation, Chromatic, Pixelate
Edit: Crop (aspect ratios), Rotate / Flip / Straighten, Perspective, Expand, Frame, Brush / Eraser, Healing, Text, Stickers (emoji)

Also: pinch-zoom, undo / redo (6 steps), hold-to-compare, save as JPG or PNG to Pictures/Lumina Studio, share, "My creations" gallery.

## Notes
- Photos are limited to 2560 px on the longest side to keep editing smooth and avoid out-of-memory errors.
- To rename the app or package: change `app_name` in `res/values/strings.xml` and refactor the package.
