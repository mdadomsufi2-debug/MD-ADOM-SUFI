package com.webtoolshub.lumina;

import android.graphics.Bitmap;

/** Describes one editing tool: its sliders and how it processes a bitmap. */
final class ToolDef {

    static final int CAT_ADJUST = 1;
    static final int CAT_EFFECTS = 2;
    static final int CAT_EDIT = 3;

    static final int T_SLIDERS = 0;
    static final int T_FILTERS = 1;
    static final int T_CROP = 2;
    static final int T_ROTATE = 3;
    static final int T_DRAW = 4;
    static final int T_HEAL = 5;
    static final int T_TEXT = 6;
    static final int T_STICKER = 7;

    interface Processor {
        Bitmap run(Bitmap src, float[] v, int color) throws Exception;
    }

    static final class Param {
        final String label;
        final float min;
        final float max;
        final float def;

        Param(String label, float min, float max, float def) {
            this.label = label;
            this.min = min;
            this.max = max;
            this.def = def;
        }
    }

    final String name;
    final int icon;
    final int category;
    final int kind;
    final int accent;
    final Param[] params;
    /** 0 = no color row, 1 = color row, 2 = color row with a "blur" option (value 0) */
    final int colorMode;
    final Processor processor;

    ToolDef(String name, int icon, int category, int kind, int accent, int colorMode,
            Processor processor, Param... params) {
        this.name = name;
        this.icon = icon;
        this.category = category;
        this.kind = kind;
        this.accent = accent;
        this.colorMode = colorMode;
        this.processor = processor;
        this.params = params;
    }
}
