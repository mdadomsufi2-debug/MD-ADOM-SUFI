package com.webtoolshub.lumina;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * Photo canvas with pinch-zoom / pan and the interactive modes used by the tools:
 * crop rectangle, freehand drawing / healing, and draggable text or stickers.
 */
public class EditorView extends View {

    static final int MODE_VIEW = 0;
    static final int MODE_CROP = 1;
    static final int MODE_DRAW = 2;
    static final int MODE_TEXT = 3;

    private static final int H_L = 1, H_T = 2, H_R = 4, H_B = 8, H_MOVE = 16;

    interface TextListener {
        void onTextSelected(TextItem item);
    }

    static final class TextItem {
        String text;
        float x;
        float y;
        float size;
        int color;
        boolean bold;
    }

    private static final class Stroke {
        final Path path = new Path();
        int kind;
        int color;
        float width;
    }

    // ---- display
    private Bitmap bitmap;
    private Bitmap original;
    private float logicalW, logicalH;
    private boolean showOriginal;
    private boolean needsFit = true;
    private final Matrix m = new Matrix();
    private final Matrix inv = new Matrix();
    private float minScale = 1f;
    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final ScaleGestureDetector scaleDetector;
    private boolean scaling;
    private boolean ignoreUntilUp;
    private float lastFocusX, lastFocusY, lastX, lastY;
    private int mode = MODE_VIEW;
    private final float density;

    // ---- crop
    private final RectF cropRect = new RectF();
    private float aspect = 0f;
    private int dragHandle = 0;
    private final Paint dimPaint = new Paint();
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint handlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // ---- draw / heal
    private Bitmap drawBase;
    private Bitmap draft;
    private Canvas draftCanvas;
    private Bitmap healSource;
    private final List<Stroke> strokes = new ArrayList<>();
    private Stroke currentStroke;
    private int drawKind = 0;
    private int drawColor = Color.WHITE;
    private float brushSizeDp = 12f;

    // ---- text
    private final List<TextItem> texts = new ArrayList<>();
    private TextItem selected;
    private TextListener textListener;
    private final Paint selPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public EditorView(Context context, AttributeSet attrs) {
        super(context, attrs);
        density = context.getResources().getDisplayMetrics().density;
        dimPaint.setColor(0x99000000);
        linePaint.setColor(Color.WHITE);
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeWidth(density);
        handlePaint.setColor(Color.WHITE);
        handlePaint.setStyle(Paint.Style.STROKE);
        handlePaint.setStrokeWidth(3.5f * density);
        handlePaint.setStrokeCap(Paint.Cap.ROUND);
        selPaint.setColor(0xFFFFFFFF);
        selPaint.setStyle(Paint.Style.STROKE);
        selPaint.setStrokeWidth(1.5f * density);
        selPaint.setPathEffect(new android.graphics.DashPathEffect(new float[]{12f, 8f}, 0f));

        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScaleBegin(ScaleGestureDetector d) {
                lastFocusX = d.getFocusX();
                lastFocusY = d.getFocusY();
                scaling = true;
                return true;
            }

            @Override
            public boolean onScale(ScaleGestureDetector d) {
                float cur = currentScale();
                float target = Math.max(minScale * 0.9f, Math.min(minScale * 10f, cur * d.getScaleFactor()));
                float f = target / cur;
                m.postScale(f, f, d.getFocusX(), d.getFocusY());
                m.postTranslate(d.getFocusX() - lastFocusX, d.getFocusY() - lastFocusY);
                lastFocusX = d.getFocusX();
                lastFocusY = d.getFocusY();
                constrain();
                invalidate();
                return true;
            }

            @Override
            public void onScaleEnd(ScaleGestureDetector d) {
                scaling = false;
            }
        });
    }

    // ================================================================ public API
    /** Shows a bitmap. k scales a down-sized preview bitmap back to the logical image size. */
    void setBitmap(Bitmap b, float k) {
        if (b == null) return;
        float nw = b.getWidth() * k, nh = b.getHeight() * k;
        boolean changed = Math.abs(nw - logicalW) > 1f || Math.abs(nh - logicalH) > 1f;
        bitmap = b;
        logicalW = nw;
        logicalH = nh;
        if (changed || needsFit) fit();
        invalidate();
    }

    void setOriginal(Bitmap b) {
        original = b;
    }

    void setShowOriginal(boolean show) {
        showOriginal = show;
        invalidate();
    }

    void setMode(int newMode) {
        mode = newMode;
        invalidate();
    }

    /** Leaves every interactive mode and drops temporary tool state. */
    void clearTools() {
        mode = MODE_VIEW;
        draft = null;
        draftCanvas = null;
        drawBase = null;
        healSource = null;
        strokes.clear();
        currentStroke = null;
        texts.clear();
        selected = null;
        dragHandle = 0;
        invalidate();
    }

    // ---- crop
    void enterCrop() {
        if (bitmap == null) return;
        mode = MODE_CROP;
        cropRect.set(0, 0, bitmap.getWidth(), bitmap.getHeight());
        aspect = 0f;
        invalidate();
    }

    /** ratio = width / height, 0 = free. */
    void setCropAspect(float ratio) {
        if (bitmap == null) return;
        aspect = ratio;
        float bw = bitmap.getWidth(), bh = bitmap.getHeight();
        if (ratio <= 0f) {
            invalidate();
            return;
        }
        float w, h;
        if (bw / bh > ratio) {
            h = bh;
            w = h * ratio;
        } else {
            w = bw;
            h = w / ratio;
        }
        cropRect.set((bw - w) / 2f, (bh - h) / 2f, (bw + w) / 2f, (bh + h) / 2f);
        invalidate();
    }

    Rect getCropRect() {
        Rect r = new Rect();
        cropRect.round(r);
        if (bitmap != null) {
            r.left = Math.max(0, r.left);
            r.top = Math.max(0, r.top);
            r.right = Math.min(bitmap.getWidth(), Math.max(r.left + 1, r.right));
            r.bottom = Math.min(bitmap.getHeight(), Math.max(r.top + 1, r.bottom));
        }
        return r;
    }

    // ---- draw / heal
    void beginDraw(Bitmap base) {
        drawBase = base;
        draft = base.copy(Bitmap.Config.ARGB_8888, true);
        draftCanvas = new Canvas(draft);
        strokes.clear();
        currentStroke = null;
        mode = MODE_DRAW;
        bitmap = base;
        invalidate();
    }

    void setDrawKind(int kind) {
        drawKind = kind;
    }

    void setDrawColor(int color) {
        drawColor = color;
    }

    void setBrushSizeDp(float dp) {
        brushSizeDp = dp;
    }

    void setHealSource(Bitmap b) {
        healSource = b;
    }

    boolean hasStrokes() {
        return !strokes.isEmpty();
    }

    void undoStroke() {
        if (strokes.isEmpty() || draft == null) return;
        strokes.remove(strokes.size() - 1);
        draftCanvas.drawBitmap(drawBase, 0, 0, null);
        for (Stroke s : strokes) draftCanvas.drawPath(s.path, paintFor(s));
        invalidate();
    }

    /** Returns the painted bitmap (or null) and releases it from the view. */
    Bitmap takeDraft() {
        Bitmap d = draft;
        draft = null;
        draftCanvas = null;
        return d;
    }

    // ---- text
    void setTextListener(TextListener l) {
        textListener = l;
    }

    float sizeFromPct(float pct) {
        if (bitmap == null) return 40f;
        return pct / 100f * Math.min(bitmap.getWidth(), bitmap.getHeight()) * 0.25f;
    }

    float pctFromSize(float size) {
        if (bitmap == null) return 40f;
        return size / (Math.min(bitmap.getWidth(), bitmap.getHeight()) * 0.25f) * 100f;
    }

    void addText(String text, float size, int color) {
        if (bitmap == null || text == null || text.isEmpty()) return;
        float[] c = {getWidth() / 2f, getHeight() / 2f};
        m.invert(inv);
        inv.mapPoints(c);
        TextItem t = new TextItem();
        t.text = text;
        t.size = size;
        t.color = color;
        t.x = Math.max(0, Math.min(bitmap.getWidth(), c[0]));
        t.y = Math.max(0, Math.min(bitmap.getHeight(), c[1]));
        texts.add(t);
        select(t);
        invalidate();
    }

    TextItem getSelected() {
        return selected;
    }

    void setSelectedSize(float size) {
        if (selected != null) {
            selected.size = size;
            invalidate();
        }
    }

    void setSelectedColor(int color) {
        if (selected != null) {
            selected.color = color;
            invalidate();
        }
    }

    void setSelectedBold(boolean bold) {
        if (selected != null) {
            selected.bold = bold;
            invalidate();
        }
    }

    void setSelectedText(String text) {
        if (selected != null && text != null && !text.isEmpty()) {
            selected.text = text;
            invalidate();
        }
    }

    void deleteSelected() {
        if (selected != null) {
            texts.remove(selected);
            select(null);
            invalidate();
        }
    }

    List<TextItem> copyTexts() {
        List<TextItem> out = new ArrayList<>();
        for (TextItem t : texts) {
            TextItem c = new TextItem();
            c.text = t.text;
            c.x = t.x;
            c.y = t.y;
            c.size = t.size;
            c.color = t.color;
            c.bold = t.bold;
            out.add(c);
        }
        return out;
    }

    /** Draws the text items on a copy of base. */
    static Bitmap bake(Bitmap base, List<TextItem> items) {
        Bitmap out = base.copy(Bitmap.Config.ARGB_8888, true);
        Canvas c = new Canvas(out);
        for (TextItem t : items) drawItem(c, t);
        return out;
    }

    private static Paint textPaint(TextItem t) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTextSize(t.size);
        p.setTextAlign(Paint.Align.CENTER);
        p.setColor(t.color);
        p.setTypeface(t.bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        p.setShadowLayer(t.size * 0.05f, 0f, t.size * 0.03f, 0x77000000);
        return p;
    }

    private static void drawItem(Canvas c, TextItem t) {
        Paint p = textPaint(t);
        Paint.FontMetrics fm = p.getFontMetrics();
        c.drawText(t.text, t.x, t.y - (fm.ascent + fm.descent) / 2f, p);
    }

    private RectF boundsOf(TextItem t) {
        Paint p = textPaint(t);
        Paint.FontMetrics fm = p.getFontMetrics();
        float w = p.measureText(t.text) / 2f + t.size * 0.15f;
        float h = (fm.descent - fm.ascent) / 2f + t.size * 0.1f;
        return new RectF(t.x - w, t.y - h, t.x + w, t.y + h);
    }

    private void select(TextItem t) {
        selected = t;
        if (textListener != null) textListener.onTextSelected(t);
    }

    // ================================================================ geometry helpers
    private float currentScale() {
        float[] v = new float[9];
        m.getValues(v);
        return v[Matrix.MSCALE_X];
    }

    private void fit() {
        int vw = getWidth(), vh = getHeight();
        if (vw == 0 || vh == 0 || logicalW <= 0f || logicalH <= 0f) {
            needsFit = true;
            return;
        }
        needsFit = false;
        float pad = 12f * density;
        float s = Math.min((vw - 2 * pad) / logicalW, (vh - 2 * pad) / logicalH);
        m.reset();
        m.postScale(s, s);
        m.postTranslate((vw - logicalW * s) / 2f, (vh - logicalH * s) / 2f);
        minScale = s;
    }

    private void constrain() {
        RectF r = new RectF(0, 0, logicalW, logicalH);
        m.mapRect(r);
        float vw = getWidth(), vh = getHeight();
        float dx = 0f, dy = 0f;
        if (r.width() <= vw) dx = (vw - r.width()) / 2f - r.left;
        else if (r.left > 0f) dx = -r.left;
        else if (r.right < vw) dx = vw - r.right;
        if (r.height() <= vh) dy = (vh - r.height()) / 2f - r.top;
        else if (r.top > 0f) dy = -r.top;
        else if (r.bottom < vh) dy = vh - r.bottom;
        m.postTranslate(dx, dy);
    }

    private float[] toImage(float x, float y) {
        float[] p = {x, y};
        m.invert(inv);
        inv.mapPoints(p);
        return p;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (logicalW > 0f) fit();
    }

    // ================================================================ drawing
    @Override
    protected void onDraw(Canvas canvas) {
        Bitmap b = bitmap;
        if (showOriginal && original != null) b = original;
        else if (mode == MODE_DRAW && draft != null) b = draft;
        if (b == null) return;

        canvas.save();
        canvas.concat(m);
        canvas.scale(logicalW / b.getWidth(), logicalH / b.getHeight());
        canvas.drawBitmap(b, 0f, 0f, bmpPaint);
        canvas.restore();

        if (showOriginal) return;
        if (mode == MODE_CROP) drawCrop(canvas);
        if (mode == MODE_TEXT) drawTexts(canvas);
    }

    private void drawCrop(Canvas canvas) {
        RectF r = new RectF(cropRect);
        m.mapRect(r);
        int vw = getWidth(), vh = getHeight();
        canvas.drawRect(0, 0, vw, r.top, dimPaint);
        canvas.drawRect(0, r.bottom, vw, vh, dimPaint);
        canvas.drawRect(0, r.top, r.left, r.bottom, dimPaint);
        canvas.drawRect(r.right, r.top, vw, r.bottom, dimPaint);

        linePaint.setAlpha(110);
        for (int i = 1; i <= 2; i++) {
            float x = r.left + r.width() * i / 3f, y = r.top + r.height() * i / 3f;
            canvas.drawLine(x, r.top, x, r.bottom, linePaint);
            canvas.drawLine(r.left, y, r.right, y, linePaint);
        }
        linePaint.setAlpha(255);
        canvas.drawRect(r, linePaint);

        float L = 22f * density;
        canvas.drawLine(r.left, r.top, r.left + L, r.top, handlePaint);
        canvas.drawLine(r.left, r.top, r.left, r.top + L, handlePaint);
        canvas.drawLine(r.right, r.top, r.right - L, r.top, handlePaint);
        canvas.drawLine(r.right, r.top, r.right, r.top + L, handlePaint);
        canvas.drawLine(r.left, r.bottom, r.left + L, r.bottom, handlePaint);
        canvas.drawLine(r.left, r.bottom, r.left, r.bottom - L, handlePaint);
        canvas.drawLine(r.right, r.bottom, r.right - L, r.bottom, handlePaint);
        canvas.drawLine(r.right, r.bottom, r.right, r.bottom - L, handlePaint);
    }

    private void drawTexts(Canvas canvas) {
        canvas.save();
        canvas.concat(m);
        for (TextItem t : texts) drawItem(canvas, t);
        canvas.restore();
        if (selected != null) {
            RectF r = boundsOf(selected);
            m.mapRect(r);
            canvas.drawRect(r, selPaint);
        }
    }

    // ================================================================ touch
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        scaleDetector.onTouchEvent(e);
        if (scaling || e.getPointerCount() > 1) {
            ignoreUntilUp = true;
            finishOneFinger();
            return true;
        }
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                ignoreUntilUp = false;
                lastX = x;
                lastY = y;
                oneFingerDown(x, y);
                break;
            case MotionEvent.ACTION_MOVE:
                if (!ignoreUntilUp) oneFingerMove(x, y);
                lastX = x;
                lastY = y;
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (!ignoreUntilUp) finishOneFinger();
                ignoreUntilUp = false;
                break;
            default:
                break;
        }
        return true;
    }

    private void oneFingerDown(float x, float y) {
        switch (mode) {
            case MODE_CROP:
                dragHandle = hitHandle(x, y);
                break;
            case MODE_DRAW:
                startStroke(x, y);
                break;
            case MODE_TEXT:
                selectAt(x, y);
                break;
            default:
                break;
        }
    }

    private void oneFingerMove(float x, float y) {
        float dxv = x - lastX, dyv = y - lastY;
        switch (mode) {
            case MODE_VIEW:
                m.postTranslate(dxv, dyv);
                constrain();
                invalidate();
                break;
            case MODE_CROP:
                if (dragHandle != 0) {
                    float s = currentScale();
                    dragCrop(dxv / s, dyv / s);
                    invalidate();
                } else {
                    m.postTranslate(dxv, dyv);
                    constrain();
                    invalidate();
                }
                break;
            case MODE_DRAW:
                extendStroke(x, y);
                break;
            case MODE_TEXT:
                if (selected != null) {
                    float s = currentScale();
                    selected.x += dxv / s;
                    selected.y += dyv / s;
                    invalidate();
                } else {
                    m.postTranslate(dxv, dyv);
                    constrain();
                    invalidate();
                }
                break;
            default:
                break;
        }
    }

    private void finishOneFinger() {
        dragHandle = 0;
        currentStroke = null;
    }

    // ---- crop interaction
    private int hitHandle(float x, float y) {
        RectF r = new RectF(cropRect);
        m.mapRect(r);
        float t = 30f * density;
        boolean nl = Math.abs(x - r.left) < t, nr = Math.abs(x - r.right) < t;
        boolean nt = Math.abs(y - r.top) < t, nb = Math.abs(y - r.bottom) < t;
        boolean inX = x > r.left - t && x < r.right + t, inY = y > r.top - t && y < r.bottom + t;
        int h = 0;
        if (nl && inY) h |= H_L;
        else if (nr && inY) h |= H_R;
        if (nt && inX) h |= H_T;
        else if (nb && inX) h |= H_B;
        if (h != 0) return h;
        if (r.contains(x, y)) return H_MOVE;
        return 0;
    }

    private void dragCrop(float dx, float dy) {
        float bw = bitmap.getWidth(), bh = bitmap.getHeight();
        float min = 48f;
        RectF before = new RectF(cropRect);
        RectF r = cropRect;
        if (dragHandle == H_MOVE) {
            float mx = Math.max(-r.left, Math.min(bw - r.right, dx));
            float my = Math.max(-r.top, Math.min(bh - r.bottom, dy));
            r.offset(mx, my);
            return;
        }
        if ((dragHandle & H_L) != 0) r.left = Math.max(0f, Math.min(r.right - min, r.left + dx));
        if ((dragHandle & H_R) != 0) r.right = Math.min(bw, Math.max(r.left + min, r.right + dx));
        if ((dragHandle & H_T) != 0) r.top = Math.max(0f, Math.min(r.bottom - min, r.top + dy));
        if ((dragHandle & H_B) != 0) r.bottom = Math.min(bh, Math.max(r.top + min, r.bottom + dy));
        if (aspect > 0f) {
            float cx = r.centerX(), cy = r.centerY();
            boolean horiz = (dragHandle & (H_L | H_R)) != 0, vert = (dragHandle & (H_T | H_B)) != 0;
            if (horiz && !vert) {
                float h = r.width() / aspect;
                r.top = cy - h / 2f;
                r.bottom = cy + h / 2f;
            } else if (vert && !horiz) {
                float w = r.height() * aspect;
                r.left = cx - w / 2f;
                r.right = cx + w / 2f;
            } else {
                float h = r.width() / aspect;
                if ((dragHandle & H_T) != 0) r.top = r.bottom - h;
                else r.bottom = r.top + h;
            }
            if (r.left < 0f || r.top < 0f || r.right > bw || r.bottom > bh
                    || r.width() < min || r.height() < min) {
                r.set(before);
            }
        }
    }

    // ---- drawing interaction
    private Paint paintFor(Stroke s) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeWidth(s.width);
        if (s.kind == 0) {
            p.setColor(s.color);
        } else if (s.kind == 1) {
            p.setShader(new BitmapShader(drawBase, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
        } else {
            Bitmap src = healSource != null ? healSource : drawBase;
            p.setShader(new BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
            p.setMaskFilter(new BlurMaskFilter(Math.max(1f, s.width * 0.3f), BlurMaskFilter.Blur.NORMAL));
        }
        return p;
    }

    private void startStroke(float x, float y) {
        if (draft == null) return;
        float[] p = toImage(x, y);
        Stroke s = new Stroke();
        s.kind = drawKind;
        s.color = drawColor;
        s.width = Math.max(1f, brushSizeDp * density / currentScale());
        s.path.moveTo(p[0], p[1]);
        s.path.lineTo(p[0] + 0.01f, p[1]);
        strokes.add(s);
        currentStroke = s;
        draftCanvas.drawPath(s.path, paintFor(s));
        invalidate();
    }

    private void extendStroke(float x, float y) {
        if (currentStroke == null || draft == null) return;
        float[] p = toImage(x, y);
        currentStroke.path.lineTo(p[0], p[1]);
        draftCanvas.drawPath(currentStroke.path, paintFor(currentStroke));
        invalidate();
    }

    // ---- text interaction
    private void selectAt(float x, float y) {
        float[] p = toImage(x, y);
        TextItem hit = null;
        for (int i = texts.size() - 1; i >= 0; i--) {
            if (boundsOf(texts.get(i)).contains(p[0], p[1])) {
                hit = texts.get(i);
                break;
            }
        }
        if (hit != selected) select(hit);
        invalidate();
    }
}
