package com.webtoolshub.lumina;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.SystemBarStyle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.core.graphics.ColorUtils;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.slider.Slider;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

public class EditorActivity extends AppCompatActivity {

    private static final int MAX_SIDE = 2560;

    private static final int[] PALETTE = {
            Color.WHITE, 0xFF000000, 0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047,
            0xFF00ACC1, 0xFF1E88E5, 0xFF8E24AA, 0xFFD81B60, 0xFF9E9E9E};

    private static final String[] EMOJI = {"😀", "😍", "😎", "🥳", "❤️", "🔥", "⭐", "✨", "🌈", "☀️",
            "🌙", "🎉", "👍", "💯", "🌸", "🍀", "😂", "🙌", "💖", "👑"};

    /** Immutable copy of the tool state, safe to use on a background thread. */
    private static final class Snap {
        final ToolDef tool;
        final float[] v;
        final int color;
        final int filter;
        final Matrix orient;

        Snap(ToolDef tool, float[] v, int color, int filter, Matrix orient) {
            this.tool = tool;
            this.v = v;
            this.color = color;
            this.filter = filter;
            this.orient = orient;
        }
    }

    private interface Job {
        Bitmap run() throws Exception;
    }

    // views
    private EditorView editorView;
    private View editorRoot, toolsPanel, adjustPanel, busyOverlay, optionsScroll, slidersScroll;
    private LinearLayout optionsRow, slidersBox;
    private TextView tvToolName;
    private ImageButton btnUndo, btnRedo, btnCompare, btnSave;
    private Slider sizeSlider;

    // state
    private EditSession session;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final ExecutorService previewer = Executors.newSingleThreadExecutor();
    private final AtomicInteger previewGen = new AtomicInteger();
    private volatile Bitmap previewSrc;
    private volatile float previewK = 1f;
    private boolean edited = false;

    private ToolDef active;
    private float[] values = new float[0];
    private int color = Color.WHITE;
    private int filterIndex = 1;
    private Matrix orient = new Matrix();

    private final List<ToolDef> visibleTools = new ArrayList<>();
    private ToolAdapter toolAdapter;
    private final List<View> swatchViews = new ArrayList<>();
    private final List<Integer> swatchColors = new ArrayList<>();

    // ================================================================ lifecycle
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        EdgeToEdge.enable(this, SystemBarStyle.dark(Color.TRANSPARENT), SystemBarStyle.dark(Color.TRANSPARENT));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        editorRoot = findViewById(R.id.editorRoot);
        editorView = findViewById(R.id.editorView);
        toolsPanel = findViewById(R.id.toolsPanel);
        adjustPanel = findViewById(R.id.adjustPanel);
        busyOverlay = findViewById(R.id.busyOverlay);
        optionsScroll = findViewById(R.id.optionsScroll);
        slidersScroll = findViewById(R.id.slidersScroll);
        optionsRow = findViewById(R.id.optionsRow);
        slidersBox = findViewById(R.id.slidersBox);
        tvToolName = findViewById(R.id.tvToolName);
        btnUndo = findViewById(R.id.btnUndo);
        btnRedo = findViewById(R.id.btnRedo);
        btnCompare = findViewById(R.id.btnCompare);
        btnSave = findViewById(R.id.btnSave);

        final View topBar = findViewById(R.id.topBar);
        final View bottomPanel = findViewById(R.id.bottomPanel);
        final int topBase = topBar.getPaddingTop();
        final int bottomBase = bottomPanel.getPaddingBottom();
        ViewCompat.setOnApplyWindowInsetsListener(editorRoot, (v, windowInsets) -> {
            Insets bars = windowInsets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            topBar.setPadding(topBar.getPaddingLeft() , topBase + bars.top, topBar.getPaddingRight(), topBar.getPaddingBottom());
            bottomPanel.setPadding(bars.left, bottomPanel.getPaddingTop(), bars.right, bottomBase + bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });

        setupTools();
        setupButtons();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                onBack();
            }
        });

        final Uri uri = getIntent().getData();
        if (uri == null) {
            finish();
            return;
        }
        showBusy(true);
        worker.execute(() -> {
            final Bitmap b = ImageIO.load(this, uri, MAX_SIDE);
            runUi(() -> {
                showBusy(false);
                if (b == null) {
                    Toast.makeText(this, R.string.msg_load_failed, Toast.LENGTH_LONG).show();
                    finish();
                    return;
                }
                session = new EditSession(b);
                editorView.setOriginal(b);
                editorView.setBitmap(b, 1f);
                updateTopButtons();
                rebuildPreviewSource();
            });
        });
    }

    @Override
    protected void onDestroy() {
        previewGen.incrementAndGet();
        worker.shutdownNow();
        previewer.shutdownNow();
        super.onDestroy();
    }

    private void runUi(Runnable r) {
        runOnUiThread(() -> {
            if (!isFinishing() && !isDestroyed()) r.run();
        });
    }

    private void showBusy(boolean b) {
        busyOverlay.setVisibility(b ? View.VISIBLE : View.GONE);
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    // ================================================================ top bar / tool list
    private void setupButtons() {
        findViewById(R.id.btnClose).setOnClickListener(v -> onBack());
        btnUndo.setOnClickListener(v -> {
            if (session != null && active == null && session.canUndo()) {
                session.undo();
                afterHistoryChange();
            }
        });
        btnRedo.setOnClickListener(v -> {
            if (session != null && active == null && session.canRedo()) {
                session.redo();
                afterHistoryChange();
            }
        });
        btnCompare.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    editorView.setShowOriginal(true);
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    editorView.setShowOriginal(false);
                    break;
                default:
                    break;
            }
            return true;
        });
        btnSave.setOnClickListener(v -> showSaveDialog());
        findViewById(R.id.btnCancelTool).setOnClickListener(v -> closeTool());
        findViewById(R.id.btnApplyTool).setOnClickListener(v -> applyTool());
    }

    private void afterHistoryChange() {
        editorView.setBitmap(session.current(), 1f);
        edited = true;
        updateTopButtons();
        rebuildPreviewSource();
    }

    private void updateTopButtons() {
        boolean idle = session != null && active == null;
        setEnabledAlpha(btnUndo, idle && session.canUndo());
        setEnabledAlpha(btnRedo, idle && session.canRedo());
        setEnabledAlpha(btnSave, idle);
        setEnabledAlpha(btnCompare, session != null);
    }

    private void setEnabledAlpha(View v, boolean enabled) {
        v.setEnabled(enabled);
        v.setAlpha(enabled ? 1f : 0.35f);
    }

    private void setupTools() {
        TabLayout tabs = findViewById(R.id.tabs);
        tabs.addTab(tabs.newTab().setText(R.string.tab_all));
        tabs.addTab(tabs.newTab().setText(R.string.tab_adjust));
        tabs.addTab(tabs.newTab().setText(R.string.tab_effects));
        tabs.addTab(tabs.newTab().setText(R.string.tab_edit));
        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                filterTools(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });
        RecyclerView rv = findViewById(R.id.rvTools);
        rv.setLayoutManager(new GridLayoutManager(this, 4));
        toolAdapter = new ToolAdapter();
        rv.setAdapter(toolAdapter);
        filterTools(0);
    }

    private void filterTools(int category) {
        visibleTools.clear();
        for (ToolDef t : Tools.ALL) {
            if (category == 0 || t.category == category) visibleTools.add(t);
        }
        toolAdapter.notifyDataSetChanged();
    }

    private class ToolAdapter extends RecyclerView.Adapter<ToolAdapter.VH> {
        class VH extends RecyclerView.ViewHolder {
            final View iconBg;
            final ImageView icon;
            final TextView name;

            VH(@NonNull View v) {
                super(v);
                iconBg = v.findViewById(R.id.iconBg);
                icon = v.findViewById(R.id.icon);
                name = v.findViewById(R.id.name);
            }
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new VH(getLayoutInflater().inflate(R.layout.item_tool, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            final ToolDef t = visibleTools.get(position);
            GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[]{ColorUtils.blendARGB(t.accent, Color.WHITE, 0.25f), t.accent});
            bg.setCornerRadius(dp(15));
            h.iconBg.setBackground(bg);
            h.icon.setImageResource(t.icon);
            h.name.setText(t.name);
            h.itemView.setOnClickListener(v -> openTool(t));
        }

        @Override
        public int getItemCount() {
            return visibleTools.size();
        }
    }

    // ================================================================ opening / closing a tool
    private void openTool(ToolDef t) {
        if (session == null || active != null) return;
        active = t;
        values = new float[t.params.length];
        for (int i = 0; i < values.length; i++) values[i] = t.params[i].def;
        color = t.colorMode == 2 ? 0 : Color.WHITE;
        filterIndex = 1;
        orient = new Matrix();
        sizeSlider = null;

        tvToolName.setText(t.name);
        optionsRow.removeAllViews();
        slidersBox.removeAllViews();
        swatchViews.clear();
        swatchColors.clear();
        editorView.clearTools();
        editorView.setBitmap(session.current(), 1f);

        switch (t.kind) {
            case ToolDef.T_FILTERS:
                addPresetChips();
                addSliders();
                break;
            case ToolDef.T_CROP:
                editorView.enterCrop();
                addAspectChips();
                break;
            case ToolDef.T_ROTATE:
                addRotateChips();
                addSliders();
                break;
            case ToolDef.T_DRAW:
                editorView.beginDraw(session.current());
                editorView.setDrawKind(0);
                editorView.setDrawColor(color);
                editorView.setBrushSizeDp(brushDp());
                addDrawChips();
                addSwatches(false);
                addSliders();
                break;
            case ToolDef.T_HEAL:
                editorView.beginDraw(session.current());
                editorView.setDrawKind(2);
                editorView.setBrushSizeDp(brushDp());
                addUndoStrokeChip();
                addSliders();
                prepareHeal();
                break;
            case ToolDef.T_TEXT:
                editorView.setMode(EditorView.MODE_TEXT);
                addTextChips();
                addSwatches(false);
                addSliders();
                bindTextListener();
                break;
            case ToolDef.T_STICKER:
                editorView.setMode(EditorView.MODE_TEXT);
                addStickerChips();
                addSliders();
                bindTextListener();
                break;
            default:
                addSliders();
                if (t.colorMode > 0) addSwatches(t.colorMode == 2);
                break;
        }

        optionsScroll.setVisibility(optionsRow.getChildCount() > 0 ? View.VISIBLE : View.GONE);
        slidersScroll.setVisibility(slidersBox.getChildCount() > 0 ? View.VISIBLE : View.GONE);
        slidersScroll.post(() -> {
            ViewGroup.LayoutParams lp = slidersScroll.getLayoutParams();
            lp.height = Math.min(slidersBox.getHeight(), dp(200));
            slidersScroll.setLayoutParams(lp);
        });

        toolsPanel.setVisibility(View.GONE);
        adjustPanel.setVisibility(View.VISIBLE);
        fade(adjustPanel);
        updateTopButtons();
        schedulePreview();
    }

    private void closeTool() {
        previewGen.incrementAndGet();
        active = null;
        sizeSlider = null;
        editorView.clearTools();
        if (session != null) editorView.setBitmap(session.current(), 1f);
        adjustPanel.setVisibility(View.GONE);
        toolsPanel.setVisibility(View.VISIBLE);
        fade(toolsPanel);
        updateTopButtons();
    }

    private void fade(View v) {
        AlphaAnimation a = new AlphaAnimation(0f, 1f);
        a.setDuration(220);
        v.startAnimation(a);
    }

    private float brushDp() {
        return active != null && active.kind == ToolDef.T_HEAL ? values[0] * 0.6f : values[0] * 0.5f + 2f;
    }

    // ================================================================ panel builders
    private void addSliders() {
        for (int i = 0; i < active.params.length; i++) addSlider(active.params[i], i);
    }

    private void addSlider(ToolDef.Param p, final int index) {
        View row = getLayoutInflater().inflate(R.layout.row_slider, slidersBox, false);
        TextView label = row.findViewById(R.id.tvLabel);
        final TextView valueTv = row.findViewById(R.id.tvValue);
        Slider slider = row.findViewById(R.id.slider);
        label.setText(p.label);
        slider.setValueFrom(p.min);
        slider.setValueTo(p.max);
        slider.setStepSize(1f);
        slider.setValue(values[index]);
        valueTv.setText(String.valueOf(Math.round(values[index])));
        slider.addOnChangeListener((s, val, fromUser) -> {
            if (!fromUser) return;
            values[index] = val;
            valueTv.setText(String.valueOf(Math.round(val)));
            onValueChanged();
        });
        if (index == 0 && active.kind >= ToolDef.T_DRAW) sizeSlider = slider;
        slidersBox.addView(row);
    }

    private void onValueChanged() {
        if (active == null) return;
        switch (active.kind) {
            case ToolDef.T_DRAW:
            case ToolDef.T_HEAL:
                editorView.setBrushSizeDp(brushDp());
                break;
            case ToolDef.T_TEXT:
            case ToolDef.T_STICKER:
                editorView.setSelectedSize(editorView.sizeFromPct(values[0]));
                break;
            case ToolDef.T_CROP:
                break;
            default:
                schedulePreview();
                break;
        }
    }

    private Chip makeChip(String label, boolean checkable) {
        Chip c = (Chip) getLayoutInflater().inflate(checkable ? R.layout.chip_choice : R.layout.chip_action,
                optionsRow, false);
        c.setText(label);
        c.setId(View.generateViewId());
        return c;
    }

    private ChipGroup newGroup() {
        ChipGroup g = new ChipGroup(this);
        g.setSingleLine(true);
        g.setSingleSelection(true);
        g.setSelectionRequired(true);
        optionsRow.addView(g, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return g;
    }

    private void addPresetChips() {
        ChipGroup g = newGroup();
        for (int i = 0; i < Fx.PRESETS.length; i++) {
            final int idx = i;
            Chip chip = makeChip(Fx.PRESETS[i], true);
            g.addView(chip);
            if (i == filterIndex) chip.setChecked(true);
            chip.setOnCheckedChangeListener((b, checked) -> {
                if (checked) {
                    filterIndex = idx;
                    schedulePreview();
                }
            });
        }
    }

    private void addAspectChips() {
        final String[] names = {"Free", "Original", "1:1", "4:5", "3:4", "4:3", "16:9", "9:16"};
        final float[] ratios = {0f, -1f, 1f, 4f / 5f, 3f / 4f, 4f / 3f, 16f / 9f, 9f / 16f};
        ChipGroup g = newGroup();
        for (int i = 0; i < names.length; i++) {
            final float ratio = ratios[i];
            Chip chip = makeChip(names[i], true);
            g.addView(chip);
            if (i == 0) chip.setChecked(true);
            chip.setOnCheckedChangeListener((b, checked) -> {
                if (!checked) return;
                float r = ratio;
                if (r < 0f) {
                    Bitmap cur = session.current();
                    r = cur.getWidth() / (float) cur.getHeight();
                }
                editorView.setCropAspect(r);
            });
        }
    }

    private void addRotateChips() {
        addActionChip("Rotate left", () -> {
            orient.postRotate(-90f);
            schedulePreview();
        });
        addActionChip("Rotate right", () -> {
            orient.postRotate(90f);
            schedulePreview();
        });
        addActionChip("Flip horizontal", () -> {
            orient.postScale(-1f, 1f);
            schedulePreview();
        });
        addActionChip("Flip vertical", () -> {
            orient.postScale(1f, -1f);
            schedulePreview();
        });
    }

    private void addActionChip(String label, final Runnable action) {
        Chip chip = makeChip(label, false);
        chip.setOnClickListener(v -> action.run());
        optionsRow.addView(chip);
    }

    private void addDrawChips() {
        ChipGroup g = newGroup();
        Chip brush = makeChip("Brush", true);
        Chip eraser = makeChip("Eraser", true);
        g.addView(brush);
        g.addView(eraser);
        brush.setChecked(true);
        brush.setOnCheckedChangeListener((b, checked) -> {
            if (checked) editorView.setDrawKind(0);
        });
        eraser.setOnCheckedChangeListener((b, checked) -> {
            if (checked) editorView.setDrawKind(1);
        });
        addUndoStrokeChip();
    }

    private void addUndoStrokeChip() {
        addActionChip("Undo stroke", editorView::undoStroke);
    }

    private void addTextChips() {
        addActionChip("Add text", () -> showTextDialog("", text ->
                editorView.addText(text, editorView.sizeFromPct(values[0]), color)));
        addActionChip("Edit", () -> {
            EditorView.TextItem sel = editorView.getSelected();
            if (sel != null) showTextDialog(sel.text, editorView::setSelectedText);
        });
        Chip bold = makeChip("Bold", true);
        bold.setOnCheckedChangeListener((b, checked) -> editorView.setSelectedBold(checked));
        optionsRow.addView(bold);
        addActionChip("Delete", editorView::deleteSelected);
    }

    private void addStickerChips() {
        for (final String e : EMOJI) {
            Chip chip = makeChip(e, false);
            chip.setTextSize(20f);
            chip.setOnClickListener(v -> editorView.addText(e, editorView.sizeFromPct(values[0]), Color.WHITE));
            optionsRow.addView(chip);
        }
        addActionChip("Delete", editorView::deleteSelected);
    }

    private void bindTextListener() {
        editorView.setTextListener(item -> {
            if (item != null && sizeSlider != null) {
                float pct = Math.max(10f, Math.min(100f, Math.round(editorView.pctFromSize(item.size))));
                values[0] = pct;
                sizeSlider.setValue(pct);
            }
        });
    }

    private void addSwatches(boolean blurOption) {
        if (blurOption) {
            TextView t = new TextView(this);
            t.setText("Blur");
            t.setTextColor(Color.WHITE);
            t.setTextSize(12f);
            t.setGravity(android.view.Gravity.CENTER);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(36));
            lp.setMargins(dp(4), dp(6), dp(4), dp(6));
            t.setLayoutParams(lp);
            addSwatchView(t, 0);
        }
        for (int c : PALETTE) {
            View v = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(36), dp(36));
            lp.setMargins(dp(5), dp(6), dp(5), dp(6));
            v.setLayoutParams(lp);
            addSwatchView(v, c);
        }
        refreshSwatches();
    }

    private void addSwatchView(View v, final int c) {
        swatchViews.add(v);
        swatchColors.add(c);
        v.setOnClickListener(x -> {
            color = c;
            refreshSwatches();
            onColorChanged();
        });
        optionsRow.addView(v);
    }

    private void refreshSwatches() {
        for (int i = 0; i < swatchViews.size(); i++) {
            int c = swatchColors.get(i);
            boolean selected = c == color;
            GradientDrawable d = new GradientDrawable();
            d.setShape(c == 0 ? GradientDrawable.RECTANGLE : GradientDrawable.OVAL);
            d.setCornerRadius(dp(18));
            d.setColor(c == 0 ? 0xFF3A3A48 : c);
            d.setStroke(selected ? dp(3) : dp(1), selected ? 0xFF9C8CFF : 0x55FFFFFF);
            swatchViews.get(i).setBackground(d);
        }
    }

    private void onColorChanged() {
        if (active == null) return;
        switch (active.kind) {
            case ToolDef.T_DRAW:
                editorView.setDrawColor(color);
                break;
            case ToolDef.T_TEXT:
                editorView.setSelectedColor(color);
                break;
            case ToolDef.T_SLIDERS:
                schedulePreview();
                break;
            default:
                break;
        }
    }

    private void showTextDialog(String initial, final Consumer<String> onOk) {
        final EditText et = new EditText(this);
        et.setText(initial);
        et.setHint(R.string.text_hint);
        et.setMaxLines(4);
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(24), dp(8), dp(24), 0);
        box.addView(et);
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.text_dialog_title)
                .setView(box)
                .setPositiveButton(R.string.btn_ok, (d, w) -> {
                    String s = et.getText().toString().trim();
                    if (!s.isEmpty()) onOk.accept(s);
                })
                .setNegativeButton(R.string.btn_cancel, null)
                .show();
    }

    // ================================================================ preview / processing
    private Snap snapshot() {
        return new Snap(active, values.clone(), color, filterIndex, new Matrix(orient));
    }

    private static Bitmap process(Snap s, Bitmap src) throws Exception {
        switch (s.tool.kind) {
            case ToolDef.T_FILTERS:
                return Fx.applyMatrix(src, Fx.preset(s.filter), s.v[0] / 100f);
            case ToolDef.T_ROTATE:
                return Fx.rotate(src, s.orient, s.v[0]);
            default:
                return s.tool.processor.run(src, s.v, s.color);
        }
    }

    private void rebuildPreviewSource() {
        if (session == null) return;
        final Bitmap cur = session.current();
        previewer.execute(() -> {
            try {
                float s = Math.min(1f, 1000f / Math.max(cur.getWidth(), cur.getHeight()));
                Bitmap p = s >= 1f ? cur : Bitmap.createScaledBitmap(cur,
                        Math.max(1, Math.round(cur.getWidth() * s)), Math.max(1, Math.round(cur.getHeight() * s)), true);
                previewK = cur.getWidth() / (float) p.getWidth();
                previewSrc = p;
            } catch (Throwable t) {
                previewSrc = null;
            }
            runUi(this::schedulePreview);
        });
    }

    private void schedulePreview() {
        final ToolDef t = active;
        final Bitmap src = previewSrc;
        if (t == null || src == null) return;
        if (t.kind != ToolDef.T_SLIDERS && t.kind != ToolDef.T_FILTERS && t.kind != ToolDef.T_ROTATE) return;
        final Snap snap = snapshot();
        final float k = previewK;
        final int gen = previewGen.incrementAndGet();
        previewer.execute(() -> {
            if (gen != previewGen.get()) return;
            try {
                final Bitmap out = process(snap, src);
                if (gen != previewGen.get()) return;
                runUi(() -> {
                    if (gen == previewGen.get() && active != null) editorView.setBitmap(out, k);
                });
            } catch (Throwable ignored) {
            }
        });
    }

    private void prepareHeal() {
        showBusy(true);
        final Bitmap cur = session.current();
        worker.execute(() -> {
            try {
                int r = Math.max(4, Math.round(14f * Math.min(cur.getWidth(), cur.getHeight()) / 1000f));
                final Bitmap blurred = Fx.blurBitmap(cur, r);
                runUi(() -> {
                    editorView.setHealSource(blurred);
                    showBusy(false);
                });
            } catch (Throwable t) {
                runUi(() -> showBusy(false));
            }
        });
    }

    // ================================================================ apply
    private void applyTool() {
        if (active == null || session == null) return;
        final ToolDef t = active;
        final Bitmap cur = session.current();
        switch (t.kind) {
            case ToolDef.T_CROP: {
                final Rect r = editorView.getCropRect();
                runHeavy(() -> Bitmap.createBitmap(cur, r.left, r.top, r.width(), r.height()));
                break;
            }
            case ToolDef.T_DRAW:
            case ToolDef.T_HEAL: {
                Bitmap draft = editorView.takeDraft();
                if (draft == null || !editorView.hasStrokes()) {
                    closeTool();
                } else {
                    commit(draft);
                    closeTool();
                }
                break;
            }
            case ToolDef.T_TEXT:
            case ToolDef.T_STICKER: {
                final List<EditorView.TextItem> items = editorView.copyTexts();
                if (items.isEmpty()) closeTool();
                else runHeavy(() -> EditorView.bake(cur, items));
                break;
            }
            default: {
                final Snap snap = snapshot();
                runHeavy(() -> process(snap, cur));
                break;
            }
        }
    }

    private void runHeavy(final Job job) {
        showBusy(true);
        worker.execute(() -> {
            try {
                final Bitmap out = job.run();
                runUi(() -> {
                    showBusy(false);
                    commit(out);
                    closeTool();
                });
            } catch (OutOfMemoryError e) {
                runUi(() -> {
                    showBusy(false);
                    Toast.makeText(this, R.string.msg_out_of_memory, Toast.LENGTH_LONG).show();
                });
            } catch (Throwable e) {
                runUi(() -> {
                    showBusy(false);
                    Toast.makeText(this, R.string.msg_tool_failed, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void commit(Bitmap out) {
        session.commit(out);
        edited = true;
        rebuildPreviewSource();
    }

    // ================================================================ save / share / back
    private void showSaveDialog() {
        if (session == null) return;
        if (active != null) {
            Toast.makeText(this, R.string.msg_finish_tool, Toast.LENGTH_SHORT).show();
            return;
        }
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.save_title)
                .setItems(new CharSequence[]{getString(R.string.save_jpg), getString(R.string.save_png),
                        getString(R.string.save_share)}, (d, which) -> export(which))
                .show();
    }

    private void export(final int which) {
        final Bitmap bmp = session.current();
        showBusy(true);
        worker.execute(() -> {
            try {
                if (which == 2) {
                    final File f = ImageIO.writeForShare(this, bmp);
                    runUi(() -> {
                        showBusy(false);
                        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType("image/jpeg");
                        send.putExtra(Intent.EXTRA_STREAM, uri);
                        send.setClipData(android.content.ClipData.newRawUri("", uri));
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(send, getString(R.string.save_share)));
                    });
                } else {
                    ImageIO.saveToGallery(this, bmp, which == 1, 95);
                    runUi(() -> {
                        showBusy(false);
                        edited = false;
                        Snackbar.make(editorRoot, R.string.msg_saved, Snackbar.LENGTH_LONG).show();
                    });
                }
            } catch (Throwable e) {
                runUi(() -> {
                    showBusy(false);
                    Toast.makeText(this, R.string.msg_save_failed, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void onBack() {
        if (active != null) {
            closeTool();
            return;
        }
        if (edited) {
            new MaterialAlertDialogBuilder(this)
                    .setTitle(R.string.discard_title)
                    .setMessage(R.string.discard_message)
                    .setNegativeButton(R.string.btn_keep_editing, null)
                    .setPositiveButton(R.string.btn_discard, (d, w) -> finish())
                    .show();
        } else {
            finish();
        }
    }
}
