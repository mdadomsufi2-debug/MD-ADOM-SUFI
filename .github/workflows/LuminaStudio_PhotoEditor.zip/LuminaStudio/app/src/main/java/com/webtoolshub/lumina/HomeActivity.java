package com.webtoolshub.lumina;

import android.content.ActivityNotFoundException;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.SystemBarStyle;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private Uri cameraUri;
    private GalleryAdapter adapter;
    private View emptyView;
    private final List<Uri> items = new ArrayList<>();

    private final ActivityResultLauncher<String> picker = registerForActivityResult(
            new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) openEditor(uri);
            });

    private final ActivityResultLauncher<Uri> camera = registerForActivityResult(
            new ActivityResultContracts.TakePicture(), ok -> {
                if (Boolean.TRUE.equals(ok) && cameraUri != null) {
                    openEditor(cameraUri);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        EdgeToEdge.enable(this, SystemBarStyle.dark(Color.TRANSPARENT), SystemBarStyle.dark(Color.TRANSPARENT));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        final View header = findViewById(R.id.homeHeader);
        final int headerTop = header.getPaddingTop();
        final View root = ((View) header.getParent());
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, windowInsets) -> {
            Insets bars = windowInsets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            v.setPadding(bars.left, 0, bars.right, bars.bottom);
            header.setPadding(header.getPaddingLeft(), headerTop + bars.top,
                    header.getPaddingRight(), header.getPaddingBottom());
            return WindowInsetsCompat.CONSUMED;
        });

        emptyView = findViewById(R.id.tvEmptyGallery);
        RecyclerView rv = findViewById(R.id.rvGallery);
        rv.setLayoutManager(new GridLayoutManager(this, 3));
        adapter = new GalleryAdapter(items, this::openEditor);
        rv.setAdapter(adapter);

        findViewById(R.id.btnOpen).setOnClickListener(v -> picker.launch("image/*"));
        findViewById(R.id.btnCamera).setOnClickListener(v -> takePhoto());
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadGallery();
    }

    private void takePhoto() {
        try {
            File dir = new File(getCacheDir(), "camera");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, "capture.jpg");
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            camera.launch(cameraUri);
        } catch (ActivityNotFoundException | IllegalArgumentException e) {
            Toast.makeText(this, R.string.msg_camera_failed, Toast.LENGTH_LONG).show();
        }
    }

    private void openEditor(Uri uri) {
        Intent i = new Intent(this, EditorActivity.class);
        i.setData(uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(i);
    }

    private void loadGallery() {
        new Thread(() -> {
            final List<Uri> list = new ArrayList<>();
            Uri collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            String selection = MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?";
            String[] args = {Environment.DIRECTORY_PICTURES + "/" + ImageIO.FOLDER + "%"};
            try (Cursor c = getContentResolver().query(collection, new String[]{MediaStore.MediaColumns._ID},
                    selection, args, MediaStore.MediaColumns.DATE_ADDED + " DESC")) {
                if (c != null) {
                    while (c.moveToNext()) list.add(ContentUris.withAppendedId(collection, c.getLong(0)));
                }
            } catch (Exception ignored) {
            }
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                items.clear();
                items.addAll(list);
                adapter.notifyDataSetChanged();
                emptyView.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
            });
        }).start();
    }
}
