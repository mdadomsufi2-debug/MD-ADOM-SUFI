package com.webtoolshub.lumina;

import android.graphics.Bitmap;

import java.util.ArrayDeque;

/** Holds the current bitmap and the undo / redo history. */
final class EditSession {

    private static final int MAX_UNDO = 6;

    final Bitmap original;
    private Bitmap current;
    private final ArrayDeque<Bitmap> undo = new ArrayDeque<>();
    private final ArrayDeque<Bitmap> redo = new ArrayDeque<>();

    EditSession(Bitmap original) {
        this.original = original;
        this.current = original;
    }

    Bitmap current() {
        return current;
    }

    void commit(Bitmap next) {
        undo.addFirst(current);
        while (undo.size() > MAX_UNDO) release(undo.pollLast());
        for (Bitmap b : redo) release(b);
        redo.clear();
        current = next;
    }

    boolean canUndo() {
        return !undo.isEmpty();
    }

    boolean canRedo() {
        return !redo.isEmpty();
    }

    void undo() {
        if (undo.isEmpty()) return;
        redo.addFirst(current);
        current = undo.pollFirst();
    }

    void redo() {
        if (redo.isEmpty()) return;
        undo.addFirst(current);
        current = redo.pollFirst();
    }

    private void release(Bitmap b) {
        if (b != null && b != original && b != current && !b.isRecycled()) b.recycle();
    }
}
