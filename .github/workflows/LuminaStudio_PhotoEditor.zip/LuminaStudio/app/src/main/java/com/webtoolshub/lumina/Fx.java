package com.webtoolshub.lumina;

import android.graphics.Bitmap;
import android.graphics.Camera;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

/** Pixel and bitmap operations. All functions return a new bitmap and never modify the source. */
final class Fx {

    private Fx() {}

    // ---------------------------------------------------------------- helpers
    private static int[] px(Bitmap b) {
        int w = b.getWidth();
        int h = b.getHeight();
        int[] a = new int[w * h];
        b.getPixels(a, 0, w, 0, 0, w, h);
        return a;
    }

    private static Bitmap bm(int[] a, int w, int h) {
        Bitmap r = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        r.setPixels(a, 0, w, 0, 0, w, h);
        return r;
    }

    private static int c(float v) {
        return v < 0f ? 0 : (v > 255f ? 255 : (int) (v + 0.5f));
    }

    private static int rgb(float r, float g, float b) {
        return 0xFF000000 | (c(r) << 16) | (c(g) << 8) | c(b);
    }

    private static int ci(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    private static float smooth(float e0, float e1, float x) {
        float t = (x - e0) / Math.max(1e-4f, e1 - e0);
        t = t < 0f ? 0f : (t > 1f ? 1f : t);
        return t * t * (3f - 2f * t);
    }

    private static float scaleOf(int w, int h) {
        return Math.min(w, h) / 1000f;
    }

    static Bitmap copy(Bitmap src) {
        return src.copy(Bitmap.Config.ARGB_8888, true);
    }

    // ---------------------------------------------------------------- blur
    private static void boxH(int[] in, int[] out, int w, int h, int r) {
        int div = 2 * r + 1;
        for (int y = 0; y < h; y++) {
            int row = y * w;
            int sr = 0, sg = 0, sb = 0;
            for (int i = -r; i <= r; i++) {
                int p = in[row + ci(i, 0, w - 1)];
                sr += (p >> 16) & 255;
                sg += (p >> 8) & 255;
                sb += p & 255;
            }
            for (int x = 0; x < w; x++) {
                out[row + x] = 0xFF000000 | ((sr / div) << 16) | ((sg / div) << 8) | (sb / div);
                int pa = in[row + Math.min(w - 1, x + r + 1)];
                int ps = in[row + Math.max(0, x - r)];
                sr += ((pa >> 16) & 255) - ((ps >> 16) & 255);
                sg += ((pa >> 8) & 255) - ((ps >> 8) & 255);
                sb += (pa & 255) - (ps & 255);
            }
        }
    }

    private static void boxV(int[] in, int[] out, int w, int h, int r) {
        int div = 2 * r + 1;
        for (int x = 0; x < w; x++) {
            int sr = 0, sg = 0, sb = 0;
            for (int i = -r; i <= r; i++) {
                int p = in[ci(i, 0, h - 1) * w + x];
                sr += (p >> 16) & 255;
                sg += (p >> 8) & 255;
                sb += p & 255;
            }
            for (int y = 0; y < h; y++) {
                out[y * w + x] = 0xFF000000 | ((sr / div) << 16) | ((sg / div) << 8) | (sb / div);
                int pa = in[Math.min(h - 1, y + r + 1) * w + x];
                int ps = in[Math.max(0, y - r) * w + x];
                sr += ((pa >> 16) & 255) - ((ps >> 16) & 255);
                sg += ((pa >> 8) & 255) - ((ps >> 8) & 255);
                sb += (pa & 255) - (ps & 255);
            }
        }
    }

    /** Approximate Gaussian blur (two box-blur passes in each direction). */
    private static int[] blur(int[] src, int w, int h, int r) {
        if (r < 1) return src.clone();
        int[] t = new int[src.length];
        int[] o = new int[src.length];
        boxH(src, t, w, h, r);
        boxV(t, o, w, h, r);
        boxH(o, t, w, h, r);
        boxV(t, o, w, h, r);
        return o;
    }

    static Bitmap blurBitmap(Bitmap src, int radius) {
        return bm(blur(px(src), src.getWidth(), src.getHeight(), radius), src.getWidth(), src.getHeight());
    }

    /** a + k * (a - blurred), per channel. */
    private static int[] unsharp(int[] a, int[] bl, float k) {
        int[] o = new int[a.length];
        for (int i = 0; i < a.length; i++) {
            int p = a[i];
            int q = bl[i];
            float r = ((p >> 16) & 255), g = ((p >> 8) & 255), b = (p & 255);
            float br = ((q >> 16) & 255), bg = ((q >> 8) & 255), bb = (q & 255);
            o[i] = rgb(r + k * (r - br), g + k * (g - bg), b + k * (b - bb));
        }
        return o;
    }

    private static void saturate(int[] a, float s) {
        for (int i = 0; i < a.length; i++) {
            int p = a[i];
            float r = ((p >> 16) & 255), g = ((p >> 8) & 255), b = (p & 255);
            float gray = 0.299f * r + 0.587f * g + 0.114f * b;
            a[i] = rgb(gray + (r - gray) * s, gray + (g - gray) * s, gray + (b - gray) * s);
        }
    }

    // ---------------------------------------------------------------- ADJUST
    /** v: brightness, contrast, saturation, warmth, highlights, shadows (all -100..100) */
    static Bitmap tune(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        int[] a = px(src);
        float br = v[0] * 1.2f, ct = 1f + v[1] / 100f, sat = 1f + v[2] / 100f;
        float warm = v[3] * 0.45f, hi = v[4] * 0.6f, sh = v[5] * 0.6f;
        for (int i = 0; i < a.length; i++) {
            int p = a[i];
            float r = ((p >> 16) & 255), g = ((p >> 8) & 255), b = (p & 255);
            float lum = 0.299f * r + 0.587f * g + 0.114f * b;
            float add = br + (lum > 128f ? hi * ((lum - 128f) / 127f) : sh * ((128f - lum) / 128f));
            r += add + warm;
            g += add;
            b += add - warm;
            r = (r - 128f) * ct + 128f;
            g = (g - 128f) * ct + 128f;
            b = (b - 128f) * ct + 128f;
            float gray = 0.299f * r + 0.587f * g + 0.114f * b;
            a[i] = rgb(gray + (r - gray) * sat, gray + (g - gray) * sat, gray + (b - gray) * sat);
        }
        return bm(a, w, h);
    }

    /** v: sharpening 0..100, structure -50..100 */
    static Bitmap details(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        float s = scaleOf(w, h);
        int[] a = px(src);
        if (v[1] != 0f) {
            int[] bl = blur(a, w, h, Math.max(2, Math.round(14 * s)));
            a = unsharp(a, bl, v[1] / 60f);
        }
        if (v[0] > 0f) {
            int[] bl = blur(a, w, h, Math.max(1, Math.round(1.6f * s)));
            a = unsharp(a, bl, v[0] / 35f);
        }
        return bm(a, w, h);
    }

    /** v: amount 0..100 */
    static Bitmap dehaze(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        int[] a = px(src);
        float k = v[0] / 100f;
        float ct = 1f + k * 0.15f, sat = 1f + k * 0.22f;
        for (int i = 0; i < a.length; i++) {
            int p = a[i];
            float r = ((p >> 16) & 255), g = ((p >> 8) & 255), b = (p & 255);
            float m = Math.min(r, Math.min(g, b));
            float haze = k * 0.5f * m;
            float d = 1f - haze / 255f;
            r = (r - haze) / d;
            g = (g - haze) / d;
            b = (b - haze) / d;
            r = (r - 128f) * ct + 128f;
            g = (g - 128f) * ct + 128f;
            b = (b - 128f) * ct + 128f;
            float gray = 0.299f * r + 0.587f * g + 0.114f * b;
            a[i] = rgb(gray + (r - gray) * sat, gray + (g - gray) * sat, gray + (b - gray) * sat);
        }
        return bm(a, w, h);
    }

    /** v: high tones, mid tones, low tones (-100..100) */
    static Bitmap tone(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        float s = scaleOf(w, h);
        int[] a = px(src);
        int[] bl = blur(a, w, h, Math.max(3, Math.round(22 * s)));
        int[] o = new int[a.length];
        for (int i = 0; i < a.length; i++) {
            int p = a[i];
            int q = bl[i];
            float r = ((p >> 16) & 255), g = ((p >> 8) & 255), b = (p & 255);
            float L = (0.299f * r + 0.587f * g + 0.114f * b) / 255f;
            float wl = (1f - L) * (1f - L), wm = 4f * L * (1f - L), wh = L * L;
            float k = (v[2] / 100f * wl + v[1] / 100f * wm + v[0] / 100f * wh) * 1.7f;
            o[i] = rgb(r + k * (r - ((q >> 16) & 255)), g + k * (g - ((q >> 8) & 255)), b + k * (b - (q & 255)));
        }
        return bm(o, w, h);
    }

    /** v: temperature, tint (-100..100) */
    static Bitmap whiteBalance(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        int[] a = px(src);
        float t = v[0] * 0.55f, ti = v[1];
        for (int i = 0; i < a.length; i++) {
            int p = a[i];
            float r = ((p >> 16) & 255), g = ((p >> 8) & 255), b = (p & 255);
            a[i] = rgb(r + t + ti * 0.2f, g - ti * 0.4f, b - t + ti * 0.2f);
        }
        return bm(a, w, h);
    }

    /** v: hue -180..180, saturation -100..100, vibrance 0..100 */
    static Bitmap color(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        int[] a = px(src);
        double ang = Math.toRadians(v[0]);
        float cs = (float) Math.cos(ang), sn = (float) Math.sin(ang);
        float m00 = 0.213f + cs * 0.787f - sn * 0.213f, m01 = 0.715f - cs * 0.715f - sn * 0.715f, m02 = 0.072f - cs * 0.072f + sn * 0.928f;
        float m10 = 0.213f - cs * 0.213f + sn * 0.143f, m11 = 0.715f + cs * 0.285f + sn * 0.140f, m12 = 0.072f - cs * 0.072f - sn * 0.283f;
        float m20 = 0.213f - cs * 0.213f - sn * 0.787f, m21 = 0.715f - cs * 0.715f + sn * 0.715f, m22 = 0.072f + cs * 0.928f + sn * 0.072f;
        float sat = 1f + v[1] / 100f, vib = v[2] / 100f;
        for (int i = 0; i < a.length; i++) {
            int p = a[i];
            float r0 = ((p >> 16) & 255), g0 = ((p >> 8) & 255), b0 = (p & 255);
            float r = m00 * r0 + m01 * g0 + m02 * b0;
            float g = m10 * r0 + m11 * g0 + m12 * b0;
            float b = m20 * r0 + m21 * g0 + m22 * b0;
            float gray = 0.299f * r + 0.587f * g + 0.114f * b;
            r = gray + (r - gray) * sat;
            g = gray + (g - gray) * sat;
            b = gray + (b - gray) * sat;
            float mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
            float amt = 1f + vib * (1f - Math.max(0f, Math.min(1f, (mx - mn) / 255f))) * 0.9f;
            gray = 0.299f * r + 0.587f * g + 0.114f * b;
            a[i] = rgb(gray + (r - gray) * amt, gray + (g - gray) * amt, gray + (b - gray) * amt);
        }
        return bm(a, w, h);
    }

    /** v: amount 0..100, contrast -100..100, brightness -100..100 */
    static Bitmap blackWhite(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        int[] a = px(src);
        float k = v[0] / 100f, ct = 1f + v[1] / 100f, br = v[2] * 1.2f;
        for (int i = 0; i < a.length; i++) {
            int p = a[i];
            float r = ((p >> 16) & 255), g = ((p >> 8) & 255), b = (p & 255);
            float gray = 0.299f * r + 0.587f * g + 0.114f * b;
            r += (gray - r) * k;
            g += (gray - g) * k;
            b += (gray - b) * k;
            a[i] = rgb((r - 128f) * ct + 128f + br, (g - 128f) * ct + 128f + br, (b - 128f) * ct + 128f + br);
        }
        return bm(a, w, h);
    }

    /** v: black point 0..120, white point 135..255, gamma 30..250 (/100) */
    static Bitmap levels(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        int[] a = px(src);
        float black = v[0], white = v[1], gamma = v[2] / 100f;
        int[] lut = new int[256];
        for (int i = 0; i < 256; i++) {
            float x = (i - black) / Math.max(1f, white - black);
            x = x < 0f ? 0f : (x > 1f ? 1f : x);
            lut[i] = c((float) (255.0 * Math.pow(x, 1.0 / gamma)));
        }
        for (int i = 0; i < a.length; i++) {
            int p = a[i];
            a[i] = 0xFF000000 | (lut[(p >> 16) & 255] << 16) | (lut[(p >> 8) & 255] << 8) | lut[p & 255];
        }
        return bm(a, w, h);
    }

    /** v: strength 0..100, saturation -50..100 */
    static Bitmap hdr(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        float s = scaleOf(w, h);
        int[] a = px(src);
        int[] bl = blur(a, w, h, Math.max(4, Math.round(28 * s)));
        a = unsharp(a, bl, v[0] / 40f);
        saturate(a, 1f + v[1] / 100f);
        return bm(a, w, h);
    }

    // ---------------------------------------------------------------- EFFECTS
    /** v: strength -100..100, size 0..100, feather 10..100 */
    static Bitmap vignette(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        int[] a = px(src);
        float cx = w / 2f, cy = h / 2f;
        float maxD = (float) Math.sqrt(cx * cx + cy * cy);
        float start = v[1] / 100f * 0.9f;
        float fe = Math.max(0.05f, v[2] / 100f * 0.8f);
        float str = v[0] / 100f;
        for (int y = 0; y < h; y++) {
            float dy = y - cy;
            for (int x = 0; x < w; x++) {
                float dx = x - cx;
                float d = (float) Math.sqrt(dx * dx + dy * dy) / maxD;
                float f = str * smooth(start, start + fe, d);
                int i = y * w + x;
                int p = a[i];
                float r = ((p >> 16) & 255), g = ((p >> 8) & 255), b = (p & 255);
                if (f >= 0f) {
                    r *= 1f - f;
                    g *= 1f - f;
                    b *= 1f - f;
                } else {
                    r += (255f - r) * -f;
                    g += (255f - g) * -f;
                    b += (255f - b) * -f;
                }
                a[i] = rgb(r, g, b);
            }
        }
        return bm(a, w, h);
    }

    private static int[] lerpMask(int[] a, int[] bl, float[] mask) {
        int[] o = new int[a.length];
        for (int i = 0; i < a.length; i++) {
            float m = mask[i];
            int p = a[i], q = bl[i];
            float r = ((p >> 16) & 255), g = ((p >> 8) & 255), b = (p & 255);
            float r2 = ((q >> 16) & 255), g2 = ((q >> 8) & 255), b2 = (q & 255);
            o[i] = rgb(r + (r2 - r) * m, g + (g2 - g) * m, b + (b2 - b) * m);
        }
        return o;
    }

    /** v: amount 0..100, focus size 10..90, transition 10..100 */
    static Bitmap lensBlur(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        float s = scaleOf(w, h);
        int[] a = px(src);
        int[] bl = blur(a, w, h, Math.max(1, Math.round(v[0] * 0.45f * s)));
        float[] mask = new float[a.length];
        float cx = w / 2f, cy = h / 2f, norm = Math.min(w, h) / 2f;
        float inner = v[1] / 100f, outer = inner + v[2] / 100f;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                float d = (float) Math.sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy)) / norm;
                mask[y * w + x] = smooth(inner, outer, d);
            }
        }
        return bm(lerpMask(a, bl, mask), w, h);
    }

    /** v: amount 0..100, focus width 5..60, transition 10..100, angle -90..90 */
    static Bitmap tiltShift(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        float s = scaleOf(w, h);
        int[] a = px(src);
        int[] bl = blur(a, w, h, Math.max(1, Math.round(v[0] * 0.45f * s)));
        float[] mask = new float[a.length];
        float cx = w / 2f, cy = h / 2f, norm = Math.min(w, h) / 2f;
        double ang = Math.toRadians(v[3]);
        float sn = (float) Math.sin(ang), cs = (float) Math.cos(ang);
        float inner = v[1] / 100f, outer = inner + v[2] / 100f;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                float d = Math.abs(-(x - cx) * sn + (y - cy) * cs) / norm;
                mask[y * w + x] = smooth(inner, outer, d);
            }
        }
        return bm(lerpMask(a, bl, mask), w, h);
    }

    /** v: length 0..100, angle 0..180 */
    static Bitmap motionBlur(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        int[] a = px(src);
        int[] o = new int[a.length];
        float len = v[0] / 100f * 0.07f * Math.max(w, h);
        double ang = Math.toRadians(v[1]);
        float dx = (float) Math.cos(ang), dy = (float) Math.sin(ang);
        int n = Math.max(1, Math.min(24, Math.round(len)));
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int sr = 0, sg = 0, sb = 0;
                for (int k = 0; k < n; k++) {
                    float t = n == 1 ? 0f : (k / (float) (n - 1) - 0.5f) * len;
                    int sx = ci(Math.round(x + dx * t), 0, w - 1);
                    int sy = ci(Math.round(y + dy * t), 0, h - 1);
                    int p = a[sy * w + sx];
                    sr += (p >> 16) & 255;
                    sg += (p >> 8) & 255;
                    sb += p & 255;
                }
                o[y * w + x] = 0xFF000000 | ((sr / n) << 16) | ((sg / n) << 8) | (sb / n);
            }
        }
        return bm(o, w, h);
    }

    private static float noise(int x, int y) {
        int n = x * 374761393 + y * 668265263;
        n = (n ^ (n >>> 13)) * 1274126177;
        n ^= n >>> 16;
        return ((n & 0xFFFF) / 32767.5f) - 1f;
    }

    /** v: amount 0..100, size 1..10 */
    static Bitmap grain(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        float s = scaleOf(w, h);
        int[] a = px(src);
        float amt = v[0] * 1.1f;
        int block = Math.max(1, Math.round(v[1] * s * 0.6f));
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                int p = a[i];
                float r = ((p >> 16) & 255), g = ((p >> 8) & 255), b = (p & 255);
                float lum = (0.299f * r + 0.587f * g + 0.114f * b) / 127.5f;
                float weight = 1f - Math.abs(lum - 1f) * 0.5f;
                float n = noise(x / block, y / block) * amt * weight;
                a[i] = rgb(r + n, g + n, b + n);
            }
        }
        return bm(a, w, h);
    }

    /** v: glow 0..100, radius 0..100 */
    static Bitmap glow(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        float s = scaleOf(w, h);
        int[] a = px(src);
        int[] bl = blur(a, w, h, Math.max(2, Math.round((8 + v[1] * 0.35f) * s)));
        float k = v[0] / 100f;
        int[] o = new int[a.length];
        for (int i = 0; i < a.length; i++) {
            int p = a[i], q = bl[i];
            float r = ((p >> 16) & 255), g = ((p >> 8) & 255), b = (p & 255);
            float r2 = ((q >> 16) & 255), g2 = ((q >> 8) & 255), b2 = (q & 255);
            float sr = 255f - (255f - r) * (255f - r2) / 255f;
            float sg = 255f - (255f - g) * (255f - g2) / 255f;
            float sb = 255f - (255f - b) * (255f - b2) / 255f;
            o[i] = rgb(r + (sr - r) * k, g + (sg - g) * k, b + (sb - b) * k);
        }
        return bm(o, w, h);
    }

    private static int[] brightPass(int[] a, float threshold) {
        int[] o = new int[a.length];
        float range = Math.max(1f, 255f - threshold);
        for (int i = 0; i < a.length; i++) {
            int p = a[i];
            float r = ((p >> 16) & 255), g = ((p >> 8) & 255), b = (p & 255);
            float lum = 0.299f * r + 0.587f * g + 0.114f * b;
            float f = Math.max(0f, lum - threshold) / range;
            o[i] = rgb(r * f, g * f, b * f);
        }
        return o;
    }

    /** v: amount 0..100, threshold 100..250, radius 0..100 */
    static Bitmap bloom(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        float s = scaleOf(w, h);
        int[] a = px(src);
        int[] bl = blur(brightPass(a, v[1]), w, h, Math.max(2, Math.round((10 + v[2] * 0.5f) * s)));
        float k = v[0] / 100f * 1.6f;
        int[] o = new int[a.length];
        for (int i = 0; i < a.length; i++) {
            int p = a[i], q = bl[i];
            o[i] = rgb(((p >> 16) & 255) + k * ((q >> 16) & 255), ((p >> 8) & 255) + k * ((q >> 8) & 255),
                    (p & 255) + k * (q & 255));
        }
        return bm(o, w, h);
    }

    /** v: amount 0..100, threshold 100..250 */
    static Bitmap halation(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        float s = scaleOf(w, h);
        int[] a = px(src);
        int[] bl = blur(brightPass(a, v[1]), w, h, Math.max(3, Math.round(26 * s)));
        float k = v[0] / 100f * 1.4f;
        int[] o = new int[a.length];
        for (int i = 0; i < a.length; i++) {
            int p = a[i], q = bl[i];
            float L = 0.299f * ((q >> 16) & 255) + 0.587f * ((q >> 8) & 255) + 0.114f * (q & 255);
            o[i] = rgb(((p >> 16) & 255) + k * L, ((p >> 8) & 255) + k * L * 0.32f, (p & 255) + k * L * 0.1f);
        }
        return bm(o, w, h);
    }

    /** v: amount 0..100 */
    static Bitmap chromatic(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        int[] a = px(src);
        int[] o = new int[a.length];
        float k = v[0] / 100f * 0.025f;
        float cx = w / 2f, cy = h / 2f;
        for (int y = 0; y < h; y++) {
            float dy = y - cy;
            for (int x = 0; x < w; x++) {
                float dx = x - cx;
                int xr = ci(Math.round(cx + dx * (1f + k)), 0, w - 1);
                int yr = ci(Math.round(cy + dy * (1f + k)), 0, h - 1);
                int xb = ci(Math.round(cx + dx * (1f - k)), 0, w - 1);
                int yb = ci(Math.round(cy + dy * (1f - k)), 0, h - 1);
                int i = y * w + x;
                int r = (a[yr * w + xr] >> 16) & 255;
                int g = (a[i] >> 8) & 255;
                int b = a[yb * w + xb] & 255;
                o[i] = 0xFF000000 | (r << 16) | (g << 8) | b;
            }
        }
        return bm(o, w, h);
    }

    /** v: block size 2..60 */
    static Bitmap pixelate(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        float s = scaleOf(w, h);
        int[] a = px(src);
        int bs = Math.max(2, Math.round(v[0] * s));
        for (int by = 0; by < h; by += bs) {
            for (int bx = 0; bx < w; bx += bs) {
                int x1 = Math.min(w, bx + bs), y1 = Math.min(h, by + bs);
                long sr = 0, sg = 0, sb = 0;
                int n = (x1 - bx) * (y1 - by);
                for (int y = by; y < y1; y++) {
                    for (int x = bx; x < x1; x++) {
                        int p = a[y * w + x];
                        sr += (p >> 16) & 255;
                        sg += (p >> 8) & 255;
                        sb += p & 255;
                    }
                }
                int col = 0xFF000000 | ((int) (sr / n) << 16) | ((int) (sg / n) << 8) | (int) (sb / n);
                for (int y = by; y < y1; y++) {
                    for (int x = bx; x < x1; x++) a[y * w + x] = col;
                }
            }
        }
        return bm(a, w, h);
    }

    // ---------------------------------------------------------------- looks (color matrices)
    static final String[] PRESETS = {"Original", "Vivid", "Warm", "Cool", "Vintage", "Fade", "Matte",
            "Cinema", "Dramatic", "Chrome", "Noir", "Silver", "Sepia"};

    private static ColorMatrix sat(float s) {
        ColorMatrix m = new ColorMatrix();
        m.setSaturation(s);
        return m;
    }

    private static ColorMatrix contrast(float ct, float bright) {
        float t = (-0.5f * ct + 0.5f) * 255f + bright;
        return new ColorMatrix(new float[]{ct, 0, 0, 0, t, 0, ct, 0, 0, t, 0, 0, ct, 0, t, 0, 0, 0, 1, 0});
    }

    private static ColorMatrix gain(float r, float g, float b) {
        return new ColorMatrix(new float[]{r, 0, 0, 0, 0, 0, g, 0, 0, 0, 0, 0, b, 0, 0, 0, 0, 0, 1, 0});
    }

    private static ColorMatrix chain(ColorMatrix... ms) {
        ColorMatrix out = new ColorMatrix();
        for (ColorMatrix m : ms) out.postConcat(m);
        return out;
    }

    static ColorMatrix preset(int i) {
        switch (i) {
            case 1: return chain(sat(1.45f), contrast(1.12f, 0f));
            case 2: return chain(gain(1.08f, 1.0f, 0.88f), sat(1.1f), contrast(1.05f, 4f));
            case 3: return chain(gain(0.9f, 1.0f, 1.1f), sat(1.05f));
            case 4: return chain(sat(0.6f), gain(1.1f, 1.0f, 0.8f), contrast(0.88f, 14f));
            case 5: return chain(sat(0.8f), contrast(0.82f, 26f));
            case 6: return chain(sat(0.9f), contrast(0.9f, 18f), gain(1f, 1f, 1.04f));
            case 7: return chain(new ColorMatrix(new float[]{1.1f, 0.05f, -0.05f, 0, -6, 0, 1.0f, 0.05f, 0, 0,
                    -0.1f, 0.1f, 1.15f, 0, 6, 0, 0, 0, 1, 0}), contrast(1.1f, 0f));
            case 8: return chain(sat(0.75f), contrast(1.35f, -12f));
            case 9: return chain(sat(1.25f), contrast(1.18f, 0f), gain(1.03f, 1f, 0.97f));
            case 10: return chain(sat(0f), contrast(1.4f, -8f));
            case 11: return chain(sat(0f), contrast(1.1f, 12f));
            case 12: return new ColorMatrix(new float[]{0.393f, 0.769f, 0.189f, 0, 0, 0.349f, 0.686f, 0.168f, 0,
                    0, 0.272f, 0.534f, 0.131f, 0, 0, 0, 0, 0, 1, 0});
            default: return new ColorMatrix();
        }
    }

    static Bitmap applyMatrix(Bitmap src, ColorMatrix cm, float intensity) {
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
        cv.drawBitmap(src, 0, 0, p);
        p.setColorFilter(new ColorMatrixColorFilter(cm));
        p.setAlpha(Math.round(255f * Math.max(0f, Math.min(1f, intensity))));
        cv.drawBitmap(src, 0, 0, p);
        return out;
    }

    // ---------------------------------------------------------------- EDIT (geometry)
    /** Applies an orientation matrix (90-degree rotations / flips) and straightens by a small angle (auto-zoomed). */
    static Bitmap rotate(Bitmap src, Matrix orient, float angle) {
        Bitmap cur = src;
        if (!orient.isIdentity()) {
            cur = Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), orient, true);
        }
        if (Math.abs(angle) < 0.05f) {
            return cur == src ? copy(src) : cur;
        }
        int w = cur.getWidth(), h = cur.getHeight();
        double th = Math.toRadians(Math.abs(angle));
        float ratio = Math.max(w / (float) h, h / (float) w);
        float zoom = (float) (Math.cos(th) + Math.sin(th) * ratio);
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        cv.translate(w / 2f, h / 2f);
        cv.rotate(angle);
        cv.scale(zoom, zoom);
        cv.translate(-w / 2f, -h / 2f);
        cv.drawBitmap(cur, 0, 0, new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG));
        return out;
    }

    /** v: vertical tilt -40..40, horizontal tilt -40..40 */
    static Bitmap perspective(Bitmap src, float[] v) {
        int w = src.getWidth(), h = src.getHeight();
        float rx = v[0] * 0.5f, ry = v[1] * 0.5f;
        if (rx == 0f && ry == 0f) return copy(src);
        Camera cam = new Camera();
        cam.setLocation(0f, 0f, -(Math.max(w, h) * 2.2f / 72f));
        cam.rotateX(rx);
        cam.rotateY(ry);
        Matrix m = new Matrix();
        cam.getMatrix(m);
        m.preTranslate(-w / 2f, -h / 2f);
        m.postTranslate(w / 2f, h / 2f);

        float[] pts = {0, 0, w, 0, w, h, 0, h};
        m.mapPoints(pts);
        float left = Math.max(pts[0], pts[6]), right = Math.min(pts[2], pts[4]);
        float top = Math.max(pts[1], pts[3]), bottom = Math.min(pts[5], pts[7]);
        float sL = (w / 2f) / Math.max(1f, w / 2f - left), sR = (w / 2f) / Math.max(1f, right - w / 2f);
        float sT = (h / 2f) / Math.max(1f, h / 2f - top), sB = (h / 2f) / Math.max(1f, bottom - h / 2f);
        float s = Math.max(1f, Math.max(Math.max(sL, sR), Math.max(sT, sB)));
        m.postScale(s, s, w / 2f, h / 2f);

        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        cv.drawColor(Color.BLACK);
        cv.drawBitmap(src, m, new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG));
        return out;
    }

    /** v: padding 0..50 (% of the shorter side). color 0 = blurred copy of the photo. */
    static Bitmap expand(Bitmap src, float[] v, int color) {
        int w = src.getWidth(), h = src.getHeight();
        int pad = Math.round(v[0] / 100f * Math.min(w, h));
        int nw = w + 2 * pad, nh = h + 2 * pad;
        Bitmap out = Bitmap.createBitmap(nw, nh, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        if (color == 0 && pad > 0) {
            Bitmap small = Bitmap.createScaledBitmap(src, Math.max(8, nw / 14), Math.max(8, nh / 14), true);
            Bitmap blurred = blurBitmap(small, 3);
            cv.drawBitmap(blurred, null, new RectF(0, 0, nw, nh), paint);
        } else {
            cv.drawColor(color == 0 ? Color.BLACK : color);
        }
        cv.drawBitmap(src, pad, pad, paint);
        return out;
    }

    /** v: border width 0..30 (%), corner radius 0..50 (%). Output keeps the same size as the input. */
    static Bitmap frame(Bitmap src, float[] v, int color) {
        int w = src.getWidth(), h = src.getHeight();
        float border = v[0] / 100f * Math.min(w, h) * 0.5f;
        RectF inner = new RectF(border, border, w - border, h - border);
        float radius = v[1] / 100f * Math.min(inner.width(), inner.height()) / 2f;
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        cv.drawColor(color == 0 ? Color.WHITE : color);
        Path clip = new Path();
        clip.addRoundRect(inner, radius, radius, Path.Direction.CW);
        cv.save();
        cv.clipPath(clip);
        cv.drawBitmap(src, null, inner, new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG));
        cv.restore();
        return out;
    }
}
