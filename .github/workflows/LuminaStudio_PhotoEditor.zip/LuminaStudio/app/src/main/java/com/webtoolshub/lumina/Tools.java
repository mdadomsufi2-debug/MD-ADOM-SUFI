package com.webtoolshub.lumina;

import android.graphics.Color;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** The list of all tools shown in the editor. */
final class Tools {

    private Tools() {}

    static final List<ToolDef> ALL;

    private static ToolDef.Param p(String label, float min, float max, float def) {
        return new ToolDef.Param(label, min, max, def);
    }

    static {
        final int A = ToolDef.CAT_ADJUST, E = ToolDef.CAT_EFFECTS, D = ToolDef.CAT_EDIT;
        final int S = ToolDef.T_SLIDERS;
        List<ToolDef> t = new ArrayList<>();

        // ---- Adjust
        t.add(new ToolDef("Tune", R.drawable.ic_tune, A, S, Color.parseColor("#7C4DFF"), 0,
                (s, v, c) -> Fx.tune(s, v),
                p("Brightness", -100, 100, 0), p("Contrast", -100, 100, 0), p("Saturation", -100, 100, 0),
                p("Warmth", -100, 100, 0), p("Highlights", -100, 100, 0), p("Shadows", -100, 100, 0)));
        t.add(new ToolDef("Details", R.drawable.ic_details, A, S, Color.parseColor("#00A8E8"), 0,
                (s, v, c) -> Fx.details(s, v),
                p("Sharpening", 0, 100, 40), p("Structure", -50, 100, 0)));
        t.add(new ToolDef("Dehaze", R.drawable.ic_dehaze, A, S, Color.parseColor("#26A69A"), 0,
                (s, v, c) -> Fx.dehaze(s, v), p("Amount", 0, 100, 40)));
        t.add(new ToolDef("Tone Contrast", R.drawable.ic_contrast, A, S, Color.parseColor("#5C6BC0"), 0,
                (s, v, c) -> Fx.tone(s, v),
                p("High tones", -100, 100, 0), p("Mid tones", -100, 100, 30), p("Low tones", -100, 100, 0)));
        t.add(new ToolDef("Levels", R.drawable.ic_levels, A, S, Color.parseColor("#8D6E63"), 0,
                (s, v, c) -> Fx.levels(s, v),
                p("Black point", 0, 120, 0), p("White point", 135, 255, 255), p("Gamma", 30, 250, 100)));
        t.add(new ToolDef("White Balance", R.drawable.ic_sun, A, S, Color.parseColor("#FFA000"), 0,
                (s, v, c) -> Fx.whiteBalance(s, v), p("Temperature", -100, 100, 0), p("Tint", -100, 100, 0)));
        t.add(new ToolDef("Color", R.drawable.ic_palette, A, S, Color.parseColor("#EC407A"), 0,
                (s, v, c) -> Fx.color(s, v),
                p("Hue", -180, 180, 0), p("Saturation", -100, 100, 0), p("Vibrance", 0, 100, 20)));
        t.add(new ToolDef("Black & White", R.drawable.ic_bw, A, S, Color.parseColor("#78909C"), 0,
                (s, v, c) -> Fx.blackWhite(s, v),
                p("Amount", 0, 100, 100), p("Contrast", -100, 100, 15), p("Brightness", -100, 100, 0)));
        t.add(new ToolDef("HDR", R.drawable.ic_hdr, A, S, Color.parseColor("#43A047"), 0,
                (s, v, c) -> Fx.hdr(s, v), p("Strength", 0, 100, 50), p("Saturation", -50, 100, 20)));

        // ---- Effects
        t.add(new ToolDef("Looks", R.drawable.ic_filters, E, ToolDef.T_FILTERS, Color.parseColor("#FF7043"), 0,
                null, p("Intensity", 0, 100, 100)));
        t.add(new ToolDef("Vignette", R.drawable.ic_vignette, E, S, Color.parseColor("#455A64"), 0,
                (s, v, c) -> Fx.vignette(s, v),
                p("Strength", -100, 100, 50), p("Size", 0, 100, 45), p("Feather", 10, 100, 60)));
        t.add(new ToolDef("Lens Blur", R.drawable.ic_blur, E, S, Color.parseColor("#29B6F6"), 0,
                (s, v, c) -> Fx.lensBlur(s, v),
                p("Amount", 0, 100, 50), p("Focus size", 10, 90, 35), p("Transition", 10, 100, 50)));
        t.add(new ToolDef("Tilt-Shift", R.drawable.ic_tilt, E, S, Color.parseColor("#26C6DA"), 0,
                (s, v, c) -> Fx.tiltShift(s, v),
                p("Amount", 0, 100, 50), p("Focus width", 5, 60, 20), p("Transition", 10, 100, 40),
                p("Angle", -90, 90, 0)));
        t.add(new ToolDef("Motion Blur", R.drawable.ic_motion, E, S, Color.parseColor("#5E35B1"), 0,
                (s, v, c) -> Fx.motionBlur(s, v), p("Length", 0, 100, 40), p("Angle", 0, 180, 0)));
        t.add(new ToolDef("Film Grain", R.drawable.ic_grain, E, S, Color.parseColor("#8D6E63"), 0,
                (s, v, c) -> Fx.grain(s, v), p("Amount", 0, 100, 35), p("Size", 1, 10, 3)));
        t.add(new ToolDef("Soft Glow", R.drawable.ic_glow, E, S, Color.parseColor("#F06292"), 0,
                (s, v, c) -> Fx.glow(s, v), p("Glow", 0, 100, 50), p("Radius", 0, 100, 50)));
        t.add(new ToolDef("Bloom", R.drawable.ic_glow, E, S, Color.parseColor("#FFB300"), 0,
                (s, v, c) -> Fx.bloom(s, v),
                p("Amount", 0, 100, 50), p("Threshold", 100, 250, 180), p("Radius", 0, 100, 50)));
        t.add(new ToolDef("Halation", R.drawable.ic_bloom, E, S, Color.parseColor("#E53935"), 0,
                (s, v, c) -> Fx.halation(s, v), p("Amount", 0, 100, 60), p("Threshold", 100, 250, 190)));
        t.add(new ToolDef("Chromatic", R.drawable.ic_chroma, E, S, Color.parseColor("#AB47BC"), 0,
                (s, v, c) -> Fx.chromatic(s, v), p("Amount", 0, 100, 40)));
        t.add(new ToolDef("Pixelate", R.drawable.ic_pixel, E, S, Color.parseColor("#66BB6A"), 0,
                (s, v, c) -> Fx.pixelate(s, v), p("Block size", 2, 60, 14)));

        // ---- Edit
        t.add(new ToolDef("Crop", R.drawable.ic_crop, D, ToolDef.T_CROP, Color.parseColor("#26A69A"), 0, null));
        t.add(new ToolDef("Rotate", R.drawable.ic_rotate_tool, D, ToolDef.T_ROTATE, Color.parseColor("#42A5F5"), 0,
                null, p("Straighten", -45, 45, 0)));
        t.add(new ToolDef("Perspective", R.drawable.ic_perspective, D, S, Color.parseColor("#7E57C2"), 0,
                (s, v, c) -> Fx.perspective(s, v), p("Vertical", -40, 40, 0), p("Horizontal", -40, 40, 0)));
        t.add(new ToolDef("Expand", R.drawable.ic_expand, D, S, Color.parseColor("#9CCC65"), 2,
                (s, v, c) -> Fx.expand(s, v, c), p("Padding", 0, 50, 12)));
        t.add(new ToolDef("Frame", R.drawable.ic_frame, D, S, Color.parseColor("#FFCA28"), 1,
                (s, v, c) -> Fx.frame(s, v, c), p("Width", 0, 30, 6), p("Corners", 0, 50, 12)));
        t.add(new ToolDef("Brush", R.drawable.ic_brush, D, ToolDef.T_DRAW, Color.parseColor("#EF5350"), 1,
                null, p("Size", 2, 100, 20)));
        t.add(new ToolDef("Healing", R.drawable.ic_heal, D, ToolDef.T_HEAL, Color.parseColor("#4DB6AC"), 0,
                null, p("Size", 5, 120, 30)));
        t.add(new ToolDef("Text", R.drawable.ic_text, D, ToolDef.T_TEXT, Color.parseColor("#26C6DA"), 1,
                null, p("Size", 10, 100, 40)));
        t.add(new ToolDef("Stickers", R.drawable.ic_sticker, D, ToolDef.T_STICKER, Color.parseColor("#FFA726"), 0,
                null, p("Size", 10, 100, 40)));

        ALL = Collections.unmodifiableList(t);
    }
}
