package com.webtoolshub.lumina;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.util.Size;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Grid of the photos saved by this app. */
public class GalleryAdapter extends RecyclerView.Adapter<GalleryAdapter.VH> {

    interface OnClick {
        void onClick(Uri uri);
    }

    private static final ExecutorService POOL = Executors.newFixedThreadPool(2);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final LruCache<String, Bitmap> CACHE = new LruCache<>(80);

    private final List<Uri> items;
    private final OnClick listener;

    GalleryAdapter(List<Uri> items, OnClick listener) {
        this.items = items;
        this.listener = listener;
    }

    static class VH extends RecyclerView.ViewHolder {
        final ImageView thumb;

        VH(@NonNull ImageView v) {
            super(v);
            thumb = v;
        }
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH((ImageView) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_gallery, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        final Uri uri = items.get(position);
        final String key = uri.toString();
        final Context ctx = h.itemView.getContext().getApplicationContext();
        final ImageView iv = h.thumb;
        iv.setTag(key);
        iv.setOnClickListener(v -> listener.onClick(uri));

        Bitmap cached = CACHE.get(key);
        if (cached != null) {
            iv.setImageBitmap(cached);
            return;
        }
        iv.setImageBitmap(null);
        POOL.execute(() -> {
            try {
                Bitmap b = ctx.getContentResolver().loadThumbnail(uri, new Size(320, 320), null);
                CACHE.put(key, b);
                MAIN.post(() -> {
                    if (key.equals(iv.getTag())) iv.setImageBitmap(b);
                });
            } catch (Exception ignored) {
            }
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
