# Google Play checklist

## Build
Android Studio -> Build -> Generate Signed App Bundle / APK -> Android App Bundle -> create a keystore.
Back up the keystore and passwords. Upload the .aab to Play Console. Target API 36 meets the current requirement.

## Store listing (copy, then edit)
**App name:** Lumina Studio  (check that the name is available; change it in strings.xml if not)

**Short description (max 80 chars):**
Free offline photo editor with 29 pro tools. No ads, no account.

**Full description:**
Lumina Studio is a free photo editor that works completely offline.

Adjust: Tune, Details, Dehaze, Tone Contrast, Levels, White Balance, Color, Black & White, HDR
Effects: 12 looks, Vignette, Lens Blur, Tilt-Shift, Motion Blur, Film Grain, Soft Glow, Bloom, Halation, Chromatic, Pixelate
Edit: Crop with aspect ratios, Rotate and Straighten, Perspective, Expand, Frame, Brush and Eraser, Healing, Text and Stickers

Pinch to zoom, undo and redo, hold to compare with the original, save as JPG or PNG, and share.
No ads. No account. No internet access. No permissions. Your photos never leave your device.

**Graphics:** `store-assets/icon-512.png`, `store-assets/feature-graphic-1024x500.png`. Take at least 4 real screenshots (home, tool grid, an adjustment, a before/after).
**Privacy policy URL:** host `PRIVACY_POLICY.md` (fill in date and email) and paste the link in Play Console.

## App content forms
Data safety: no data collected, no data shared. Ads: No. Content rating: complete the questionnaire honestly.

## Avoid rejection
- Do not use names or logos of other editing apps. Tool names here are generic.
- Only describe features the app really has. Healing is a smoothing brush (not AI object removal) and there are no AI portrait tools.
- Use real screenshots.
